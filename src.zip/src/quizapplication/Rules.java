package quizapplication;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Rules extends JFrame implements ActionListener{

    String name;
    JButton start, back;
    
    Rules(String name) {
        this.name = name;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel heading = new JLabel("Welcome " + name + " to Megaminds");
        heading.setBounds(50, 20, 700, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 28));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
        JLabel rules = new JLabel();
        rules.setBounds(20, 90, 700, 350);
        rules.setFont(new Font("Tahoma", Font.PLAIN, 16));
        rules.setText(
            "<html>"+   
                "1. Please DO NOT USE THE BACK BUTTON on the browser or on the keyboard, to avoid session lapse." + "<br><br>" +
                "2. After finishing the paper, when you click on submit button, the marks will be displayed to you immediately." + "<br><br>" +
                "3. The online exam will be of objective type and will be of 1 hour duration." + "<br><br>" +
                "4. Please give your exam from such a place where there is no power break down and has a strong internet connection" + "<br><br>" +
                "5. Student will appear of the exam on the scheduled date and time." + "<br><br>" +
                "6. The online exam will be available on this url  <b>http://java.exam.co.in</b> onlu." + "<br><br>" +
                "7.  Once logged in, you cannot login again for the same subjet." + "<br><br>" +"<html>"
             );
        add(rules);
        
        back = new JButton("Back");
        back.setBounds(250, 500, 100, 30);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);
        
        start = new JButton("Start");
        start.setBounds(400, 500, 100, 30);
        start.setBackground(new Color(30, 144, 254));
        start.setForeground(Color.WHITE);
        start.addActionListener(this);
        add(start);
        
        setSize(800, 650);
        setLocation(350, 100);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == start) {
            setVisible(false);
            new Quiz(name);
        } else {
            setVisible(false);
            new Login();
        }
    }
    
    public static void main(String[] args) {
        new Rules("User");
    }
}
